from flask import Flask, request, jsonify
from flask_cors import CORS
from google import genai
import traceback

app = Flask(__name__)
CORS(app)

# 🔑 API 키 (나중에 .env로 바꾸는 걸 추천)
client = genai.Client(api_key="AQ.Ab8RN6I3eQAhWN2XCdelI8pQHh71VHzlEfqY5-SCY3RsMOdwBg")

@app.route("/chat", methods=["POST"])
def chat():
    try:
        # 요청 데이터
        data = request.get_json()
        message = data.get("message", "")

        if not message:
            return jsonify({
                "reply": "메시지가 비어있습니다."
            }), 400

        # Gemini 호출
        response = client.models.generate_content(
            model="gemini-1.5-flash",
            contents=message
        )

        # ✅ 안전하게 응답 추출 (핵심)
        reply = (
            response.candidates[0].content.parts[0].text
            if response.candidates
            and response.candidates[0].content.parts
            else "응답을 받을 수 없습니다."
        )

        return jsonify({
            "reply": reply
        })

    except Exception as e:
        print(traceback.format_exc())
        return jsonify({
            "reply": "서버 오류 발생",
            "error": str(e)
        }), 500


if __name__ == "__main__":
    app.run(debug=True)