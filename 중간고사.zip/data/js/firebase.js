import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDIX5YMMh252PBjO7FqJWgLwSTMgZvE7c4",
  authDomain: "my-wep-test.firebaseapp.com",
  projectId: "my-wep-test",
  storageBucket: "my-wep-test.appspot.com",
  messagingSenderId: "449770145805",
  appId: "1:449770145805:web:7ad6f51e1027470d55ed44"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);