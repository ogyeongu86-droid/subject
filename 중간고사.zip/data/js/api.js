const apiKey = "";
const city = "Seoul";

async function getWeather() {
  try {
    // 현재 날씨
    const res = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=kr`
    );

    const data = await res.json();

    document.getElementById("weatherResult").innerText =
      `현재 기온: ${data.main.temp}°C / ${data.weather[0].description}`;

    document.getElementById("temp").innerText = `${data.main.temp}°C`;
    document.getElementById("humidity").innerText = `${data.main.humidity}%`;

    document.getElementById("dust").innerText = "좋음"; // 임시

    // 시간별
    const res2 = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric&lang=kr`
    );

    const data2 = await res2.json();

    const box = document.getElementById("hourlyBox");
    box.innerHTML = "";

    data2.list.slice(0, 8).forEach(item => {
      const time = item.dt_txt.split(" ")[1].slice(0,5);
      const temp = Math.round(item.main.temp);

      const div = document.createElement("div");
      div.className = "hour-item";
      div.innerHTML = `
        ${time}
        <span>☁</span>
        <span>${temp}°</span>
      `;

      box.appendChild(div);
    });

  } catch (e) {
    console.error(e);
    document.getElementById("weatherResult").innerText = "날씨 불러오기 실패";
  }
}