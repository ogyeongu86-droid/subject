import { auth } from './firebase.js';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

window.signup = () => {
  createUserWithEmailAndPassword(auth, email.value, password.value)
    .then(()=>alert("회원가입 성공"))
    .catch(e=>alert(e.message));
}

window.login = () => {
  signInWithEmailAndPassword(auth, email.value, password.value)
    .then(()=>location.href='mypage.html')
    .catch(e=>alert(e.message));
}

window.logout = () => {
  signOut(auth).then(()=>location.href='login.html');
}

onAuthStateChanged(auth, (user)=>{
  if(user && document.getElementById('userEmail')){
    userEmail.innerText = user.email;
  }
});