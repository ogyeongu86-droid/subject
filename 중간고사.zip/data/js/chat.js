const chat = document.getElementById("chat");
const msg = document.getElementById("msg");

// 로그인 체크 (localStorage 방식)
const user = localStorage.getItem("loginUser");

if (!user) {
  alert("로그인 필요");
  location.href = "login.html";
}

// 메시지 추가 함수
function addMsg(text, cls) {
  const div = document.createElement("div");
  div.className = "msg " + cls;
  div.innerHTML = text.replace(/\n/g, "<br>");
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

// 전송 함수
window.send = async () => {
  const text = msg.value;
  if (!text) return;

  addMsg(text, "user");
  msg.value = "";

  const loading = document.createElement("div");
  loading.className = "msg bot";
  loading.innerText = "생각중...";
  chat.appendChild(loading);

  try {
    // ✅ Flask 서버로 변경된 fetch
    const res = await fetch("http://127.0.0.1:5000/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        message: text
      })
    });

    const data = await res.json();
    const reply = data.reply;

    loading.remove();

    if (!reply) {
      addMsg("응답 오류", "bot");
      return;
    }

    addMsg(reply, "bot");

  } catch (e) {
    console.error(e);
    loading.remove();
    addMsg("서버 오류 발생", "bot");
  }
};

// 엔터 입력
msg.addEventListener("keydown", (e) => {
  if (e.key === "Enter") send();
});

let currentMode = "Gemini 상담";

window.selectTab = (e, name) => {
  currentMode = name;

  // active UI 처리
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  e.target.classList.add("active");

  // 🔥 채팅 초기화
  chat.innerHTML = "";

  // 🔥 올바른 출력
  addMsg(`👉 ${name} 모드로 변경됨`, "bot");
};

let chats = {
  gemini: [],
  study: [],
  code: []
};