document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("themeToggle");
  if (!btn) return;

  const root = document.documentElement;

  // 초기 상태
  if (root.classList.contains("light")) {
    btn.innerText = "☀️";
  } else {
    btn.innerText = "🌙";
  }

  btn.onclick = () => {
    root.classList.toggle("light");

    const isLight = root.classList.contains("light");
    localStorage.setItem("theme", isLight ? "light" : "dark");

    btn.innerText = isLight ? "☀️" : "🌙";
  };
});